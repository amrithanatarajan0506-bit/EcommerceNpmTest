# E-commerce Performance Testing (Load + Stress) - STA Lab Practical

## 1. Requirements
| Item | Version | Link |
|---|---|---|
| Node.js (includes npm) | 18 or newer (LTS) | https://nodejs.org |
| VS Code | any | https://code.visualstudio.com |
| Web browser | Chrome/Edge (to view the report) | - |
| Internet | only for `npm install` and for graphs in the report | - |

Check installation in the VS Code terminal:  `node -v`  and  `npm -v`

## 2. Setup (once)
1. Unzip the folder and open it in VS Code (File > Open Folder).
2. Open terminal (Ctrl + `) and run:
   npm install

## 3. Run the e-commerce app (optional - to see/demo it)
   npm start
Open http://localhost:3000 in the browser (browse, search, add to cart, checkout). Stop with Ctrl+C.

## 4. Run the performance tests
Keep the app stopped (the test script starts it automatically) or running - both work.

Quick demo (about 1 minute):
   npm run test:quick          (works on Windows, Mac, Linux)

Full test (about 3-4 minutes) - use this for your final report:
   npm run test:perf

The single command does everything automatically:
Step 1 website opens in browser -> Step 2 baseline -> Step 3 load test -> Step 4 stress test -> Step 5 report opens in browser.
(To stop the browser from opening automatically: PowerShell  $env:NO_OPEN=1 ; CMD  set NO_OPEN=1)

## 5. Get the report
After the run, open:  report/performance-report.html  (right-click > Open with Live Server / or open in browser)
Also generated: report/results.csv (open in Excel) and report/results.json.
To submit as PDF: open the HTML in Chrome > Ctrl+P > Save as PDF.

## 6. Change test settings
Edit tests/config.js : users per stage, stage duration, and SLA limits (avg time, p99, error %).
Edit server.js (or env DB_POOL / MAX_QUEUE) to change the app capacity and re-run to compare "before vs after tuning".

## 7. Project structure
server.js                  e-commerce app (system under test)
public/index.html          web front end
tests/config.js            test configuration
tests/run-tests.js         baseline + load + stress runner (autocannon)
tests/report-generator.js  builds the HTML report
report/                    generated reports

## 8. Tips
- Close other heavy programs while testing (client and server share your CPU).
- If port 3000 is busy: PowerShell  $env:PORT=3001 ; CMD  set PORT=3001  - then run again.
- Run the full test 2-3 times; numbers vary a little each time - that is normal.

## 9. Java version (for STA lab)
`java-test/` has Java programs (MiniLoadTest.java, LoadStressTest.java). Start the app (`npm start`), then:
   cd java-test
   javac LoadStressTest.java
   java LoadStressTest
Report: java-test/java-report.html
