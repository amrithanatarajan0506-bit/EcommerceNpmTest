@echo off
cd /d "%~dp0"
curl -s -o nul http://localhost:3000/api/health
if errorlevel 1 (
  echo ERROR: ShopEasy app is not running. Start it first: start-app.bat
  exit /b 1
)
javac LoadStressTest.java
if errorlevel 1 exit /b 1
java LoadStressTest
start "" java-report.html
