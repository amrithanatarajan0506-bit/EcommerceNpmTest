import java.io.FileWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * FULL version: load test + stress test + HTML report.
 * Run:  javac LoadStressTest.java
 *       java LoadStressTest [baseUrl] [secondsPerStage]
 * The ShopEasy app must be running (http://localhost:3000).
 */
public class LoadStressTest {

    static String base = "http://localhost:3000";
    static int seconds = 15;
    static final String[] PATHS = {"/api/products", "/api/products/7", "/api/search?q=phone"};
    static final List<String[]> rows = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        if (args.length > 0) base = args[0];
        if (args.length > 1) seconds = Integer.parseInt(args[1]);

        System.out.println("=== LOAD TEST (expected traffic) ===");
        for (int users : new int[]{10, 50, 100}) runStage("Load", users);

        System.out.println("=== STRESS TEST (beyond capacity) ===");
        for (int users : new int[]{200, 400, 800, 1200}) runStage("Stress", users);

        writeReport();
    }

    static void runStage(String type, int users) throws Exception {
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
        List<Long> times = Collections.synchronizedList(new ArrayList<>());
        AtomicInteger errors = new AtomicInteger();
        long begin = System.currentTimeMillis();
        long endTime = begin + seconds * 1000L;

        ExecutorService pool = Executors.newFixedThreadPool(users);   // one thread = one virtual user
        for (int i = 0; i < users; i++) {
            pool.submit(() -> {
                int n = 0;
                while (System.currentTimeMillis() < endTime) {
                    String path = PATHS[n++ % PATHS.length];
                    long t = System.nanoTime();
                    try {
                        HttpRequest req = HttpRequest.newBuilder(URI.create(base + path))
                                .timeout(Duration.ofSeconds(10)).GET().build();
                        HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
                        if (res.statusCode() >= 400) errors.incrementAndGet();   // e.g. 503 overload
                    } catch (Exception e) {
                        errors.incrementAndGet();                                // timeout / refused
                    }
                    times.add((System.nanoTime() - t) / 1_000_000);              // response time in ms
                }
            });
        }
        pool.shutdown();
        pool.awaitTermination(seconds + 30, TimeUnit.SECONDS);

        double secs = (System.currentTimeMillis() - begin) / 1000.0;
        List<Long> sorted = new ArrayList<>(times);
        Collections.sort(sorted);
        int total = sorted.size();
        double avg = sorted.stream().mapToLong(Long::longValue).average().orElse(0);
        long p90 = sorted.get((int) Math.max(0, Math.ceil(total * 0.90) - 1));
        long p99 = sorted.get((int) Math.max(0, Math.ceil(total * 0.99) - 1));
        double throughput = total / secs;
        double errPct = errors.get() * 100.0 / total;
        boolean pass = avg <= 500 && p99 <= 2000 && errPct <= 1;

        String[] row = {type, String.valueOf(users), String.valueOf(total), String.format("%.1f", avg),
                String.valueOf(p90), String.valueOf(p99), String.format("%.1f", throughput),
                String.format("%.2f", errPct), pass ? "PASS" : "FAIL"};
        rows.add(row);
        System.out.printf("%-7s users=%-5d requests=%-7d avg=%7.1f ms  p90=%5d  p99=%5d  throughput=%8.1f req/s  errors=%6.2f %%  %s%n",
                type, users, total, avg, p90, p99, throughput, errPct, row[8]);
    }

    static void writeReport() throws Exception {
        StringBuilder h = new StringBuilder("<html><body style='font-family:Arial'><h2>Performance Test Report - ShopEasy</h2>");
        h.append("<p>Load and stress test using Java threads and HttpClient. SLA: avg &le; 500 ms, p99 &le; 2000 ms, errors &le; 1%.</p>");
        h.append("<table border='1' cellpadding='6' style='border-collapse:collapse'><tr>")
         .append("<th>Test</th><th>Users</th><th>Requests</th><th>Avg (ms)</th><th>p90 (ms)</th><th>p99 (ms)</th><th>Throughput (req/s)</th><th>Error %</th><th>Result</th></tr>");
        for (String[] r : rows) {
            h.append("<tr>");
            for (String c : r) h.append("<td>").append(c).append("</td>");
            h.append("</tr>");
        }
        h.append("</table></body></html>");
        try (FileWriter w = new FileWriter("java-report.html")) { w.write(h.toString()); }
        System.out.println("Report written: java-report.html");
    }
}
