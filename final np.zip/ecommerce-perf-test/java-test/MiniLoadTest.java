import java.net.URI;
import java.net.http.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** MINI version - easy to write in the lab. Change 'users' to 500+ to make it a stress test. */
public class MiniLoadTest {
    public static void main(String[] args) throws Exception {
        int users = 50, seconds = 10;
        String url = "http://localhost:3000/api/products";

        HttpClient client = HttpClient.newHttpClient();
        List<Long> times = Collections.synchronizedList(new ArrayList<>());
        AtomicInteger errors = new AtomicInteger();
        long end = System.currentTimeMillis() + seconds * 1000L;

        ExecutorService pool = Executors.newFixedThreadPool(users);   // each thread = one user
        for (int i = 0; i < users; i++) {
            pool.submit(() -> {
                while (System.currentTimeMillis() < end) {
                    long t = System.currentTimeMillis();
                    try {
                        HttpResponse<String> r = client.send(
                            HttpRequest.newBuilder(URI.create(url)).build(),
                            HttpResponse.BodyHandlers.ofString());
                        if (r.statusCode() >= 400) errors.incrementAndGet();
                    } catch (Exception e) {
                        errors.incrementAndGet();
                    }
                    times.add(System.currentTimeMillis() - t);          // response time
                }
            });
        }
        pool.shutdown();
        pool.awaitTermination(60, TimeUnit.SECONDS);

        long sum = 0;
        for (long x : times) sum += x;
        int total = times.size();
        System.out.println("Users       : " + users);
        System.out.println("Requests    : " + total);
        System.out.println("Avg time    : " + sum / total + " ms");
        System.out.println("Throughput  : " + total / seconds + " req/s");
        System.out.println("Error rate  : " + errors.get() * 100.0 / total + " %");
    }
}
