// Central configuration for all performance tests. Edit values here.
const QUICK = process.env.QUICK === '1' || process.argv.includes('--quick');

module.exports = {
  PORT: process.env.PORT || 3000,
  BASE_URL: process.env.BASE_URL || `http://localhost:${process.env.PORT || 3000}`,

  // seconds each stage runs (QUICK mode is for a fast demo/check)
  DURATION: QUICK ? 4 : Number(process.env.DURATION || 15),
  BASELINE_DURATION: QUICK ? 3 : 5,

  // number of virtual users (concurrent connections) per stage
  LOAD_STAGES: QUICK ? [10, 50] : [10, 25, 50, 100],         // expected normal -> peak traffic
  STRESS_STAGES: QUICK ? [200, 500] : [100, 200, 400, 800, 1200], // beyond capacity

  // Acceptance criteria (SLA). A stage "passes" only if ALL are met.
  SLA: {
    avgMs: 500,      // average response time
    p99Ms: 2000,     // 99th percentile response time
    errorPct: 1,     // max error rate in %
  },
};
