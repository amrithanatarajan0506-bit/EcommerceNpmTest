/**
 * Performance test runner:
 *  1) Baseline  - each endpoint alone (10 users)
 *  2) Load test - mixed shopping traffic, increasing users up to expected peak
 *  3) Stress    - users pushed far beyond capacity to find the breaking point
 * Collects response time, throughput, error rate -> report/ (JSON, CSV, HTML)
 */
const autocannon = require('autocannon');
const { spawn, exec } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const { buildReport } = require('./report-generator');

const JSON_H = { 'content-type': 'application/json' };
const ENDPOINTS = [
  { name: 'Browse products', method: 'GET',  path: '/api/products' },
  { name: 'Product detail',  method: 'GET',  path: '/api/products/7' },
  { name: 'Search',          method: 'GET',  path: '/api/search?q=phone' },
  { name: 'Add to cart',     method: 'POST', path: '/api/cart', headers: JSON_H,
    body: JSON.stringify({ userId: 'u1', productId: 3, qty: 1 }) },
  { name: 'Checkout',        method: 'POST', path: '/api/checkout', headers: JSON_H, body: '{}' },
];
const pick = (n) => ENDPOINTS.find((e) => e.name === n);

// Realistic shopping mix: mostly browsing, fewer purchases
const MIX = [
  ...Array(3).fill(pick('Browse products')),
  ...Array(2).fill(pick('Product detail')),
  ...Array(2).fill(pick('Search')),
  ...Array(2).fill(pick('Add to cart')),
  pick('Checkout'),
].map(({ method, path, headers, body }) => ({ method, path, headers, body }));

function healthy() {
  return new Promise((resolve) => {
    http.get(cfg.BASE_URL + '/api/health', (r) => { r.resume(); resolve(r.statusCode === 200); })
      .on('error', () => resolve(false));
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Opens a URL / file in the default browser (set NO_OPEN=1 to disable)
function openInBrowser(target) {
  if (process.env.NO_OPEN === '1') return;
  const cmd = process.platform === 'win32' ? `start "" "${target}"`
    : process.platform === 'darwin' ? `open "${target}"` : `xdg-open "${target}"`;
  exec(cmd, () => {});
}

function run(connections, duration, requests) {
  return new Promise((resolve, reject) => {
    autocannon({ url: cfg.BASE_URL, connections, duration, timeout: 10, requests }, (err, res) =>
      err ? reject(err) : resolve(res));
  });
}

function summarize(label, users, r) {
  const failed = r.non2xx + r.errors + r.timeouts;
  const attempts = r.requests.total + r.errors + r.timeouts;
  const errorPct = attempts ? (failed / attempts) * 100 : 0;
  const s = {
    label, users,
    durationSec: Math.round(r.duration),
    totalRequests: attempts,
    success: r['2xx'],
    failed, http5xxOrNon2xx: r.non2xx, connErrors: r.errors, timeouts: r.timeouts,
    errorPct: +errorPct.toFixed(2),
    avgMs: +r.latency.average.toFixed(1),
    p50Ms: r.latency.p50,
    p90Ms: r.latency.p90,
    p99Ms: r.latency.p99,
    maxMs: r.latency.max,
    rps: +(r['2xx'] / r.duration).toFixed(1),          // successful req/s
    rpsAll: +r.requests.average.toFixed(1),            // all responses req/s
    mbPerSec: +(r.throughput.average / 1024 / 1024).toFixed(3),
  };
  s.pass = s.avgMs <= cfg.SLA.avgMs && s.p99Ms <= cfg.SLA.p99Ms && s.errorPct <= cfg.SLA.errorPct;
  return s;
}

function show(title, rows) {
  console.log(`\n=== ${title} ===`);
  console.table(rows.map((x) => ({
    Test: x.label, Users: x.users, Requests: x.totalRequests, 'Avg ms': x.avgMs, 'p90 ms': x.p90Ms,
    'p99 ms': x.p99Ms, 'Req/s': x.rps, 'Err %': x.errorPct, SLA: x.pass ? 'PASS' : 'FAIL',
  })));
}

async function main() {
  let child = null;
  if (!(await healthy())) {
    console.log('Server not running - starting it automatically...');
    child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')],
      { env: { ...process.env, PORT: cfg.PORT }, stdio: 'ignore' });
    for (let i = 0; i < 30 && !(await healthy()); i++) await sleep(300);
    if (!(await healthy())) throw new Error('Could not start server');
  }
  console.log('\n[Step 1] E-commerce web application is running -> opening in browser');
  openInBrowser(cfg.BASE_URL);
  await sleep(5000); // time to see the website before testing starts
  console.log(`Target: ${cfg.BASE_URL}  | stage duration: ${cfg.DURATION}s`);
  const startedAt = new Date();

  try {
    console.log('\n[Step 2] Baseline (single endpoints, 10 users)');
    const baseline = [];
    for (const e of ENDPOINTS) {
      process.stdout.write(`   ${e.name} ... `);
      const r = await run(10, cfg.BASELINE_DURATION, [{ method: e.method, path: e.path, headers: e.headers, body: e.body }]);
      baseline.push(summarize(e.name, 10, r)); console.log('done');
      await sleep(1000);
    }
    show('BASELINE', baseline);

    console.log('\n[Step 3] Load test (mixed traffic)');
    const load = [];
    for (const u of cfg.LOAD_STAGES) {
      process.stdout.write(`   ${u} users ... `);
      load.push(summarize(`Load ${u}`, u, await run(u, cfg.DURATION, MIX))); console.log('done');
      await sleep(2000);
    }
    show('LOAD TEST', load);

    console.log('\n[Step 4] Stress test (beyond capacity)');
    const stress = [];
    for (const u of cfg.STRESS_STAGES) {
      process.stdout.write(`   ${u} users ... `);
      stress.push(summarize(`Stress ${u}`, u, await run(u, cfg.DURATION, MIX))); console.log('done');
      await sleep(3000);
    }
    show('STRESS TEST', stress);

    const results = { startedAt, finishedAt: new Date(), config: cfg, baseline, load, stress };
    const dir = path.join(__dirname, '..', 'report');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'results.json'), JSON.stringify(results, null, 2));
    const csvRows = [['Phase', 'Test', 'Users', 'Requests', 'Failed', 'ErrorPct', 'AvgMs', 'P50Ms', 'P90Ms', 'P99Ms', 'MaxMs', 'ReqPerSec', 'MBPerSec', 'SLA']];
    for (const [phase, arr] of [['Baseline', baseline], ['Load', load], ['Stress', stress]])
      arr.forEach((x) => csvRows.push([phase, x.label, x.users, x.totalRequests, x.failed, x.errorPct, x.avgMs, x.p50Ms, x.p90Ms, x.p99Ms, x.maxMs, x.rps, x.mbPerSec, x.pass ? 'PASS' : 'FAIL']));
    fs.writeFileSync(path.join(dir, 'results.csv'), csvRows.map((r) => r.join(',')).join('\n'));
    fs.writeFileSync(path.join(dir, 'performance-report.html'), buildReport(results));
    console.log('\n[Step 5] Report generated -> report/performance-report.html  (also results.json, results.csv)');
    openInBrowser(path.join(dir, 'performance-report.html'));
  } finally {
    if (child) child.kill();
  }
}

main().catch((e) => { console.error('Test run failed:', e.message); process.exit(1); });
