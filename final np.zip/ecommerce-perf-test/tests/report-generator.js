/** Builds a self-contained HTML performance test report from the results object. */
const os = require('os');

const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

function table(rows) {
  return `<table><thead><tr><th>Test</th><th>Users</th><th>Total Req</th><th>Failed</th><th>Error %</th>
  <th>Avg (ms)</th><th>p50</th><th>p90</th><th>p99</th><th>Max</th><th>Req/s</th><th>MB/s</th><th>SLA</th></tr></thead><tbody>
  ${rows.map((x) => `<tr><td>${esc(x.label)}</td><td>${x.users}</td><td>${x.totalRequests}</td><td>${x.failed}</td>
  <td class="${x.errorPct > 1 ? 'bad' : ''}">${x.errorPct}</td><td>${x.avgMs}</td><td>${x.p50Ms}</td><td>${x.p90Ms}</td>
  <td>${x.p99Ms}</td><td>${x.maxMs}</td><td>${x.rps}</td><td>${x.mbPerSec}</td>
  <td class="${x.pass ? 'ok' : 'bad'}">${x.pass ? 'PASS' : 'FAIL'}</td></tr>`).join('')}</tbody></table>`;
}

function analyse(r) {
  const { load, stress, config } = r;
  const all = [...load, ...stress];
  const maxStable = all.filter((x) => x.pass).sort((a, b) => b.rps - a.rps)[0];
  const peak = all.slice().sort((a, b) => b.rps - a.rps)[0];
  const breaking = stress.find((x) => !x.pass) || null;
  const loadOk = load.every((x) => x.pass);
  const firstErr = all.find((x) => x.errorPct > 0);
  const worstStress = stress[stress.length - 1];
  const lines = [];

  lines.push(`<b>Load test:</b> ${loadOk
    ? `the application met every acceptance criterion for all load levels up to ${load[load.length - 1].users} concurrent users. At the highest load level it served ${load[load.length - 1].rps} req/s with an average response time of ${load[load.length - 1].avgMs} ms and an error rate of ${load[load.length - 1].errorPct}%.`
    : `the application did NOT meet the acceptance criteria at some load levels (see FAIL rows) - it is not ready for the expected peak traffic.`}`);
  if (maxStable) lines.push(`<b>Maximum stable throughput:</b> ${maxStable.rps} req/s (at ${maxStable.users} users, avg ${maxStable.avgMs} ms, error ${maxStable.errorPct}%).`);
  if (peak) lines.push(`<b>Peak throughput observed:</b> ${peak.rps} successful req/s at ${peak.users} users.`);
  lines.push(breaking
    ? `<b>Breaking point:</b> the system first violated the acceptance criteria at <b>${breaking.users} concurrent users</b> (avg ${breaking.avgMs} ms, p99 ${breaking.p99Ms} ms, error rate ${breaking.errorPct}%).`
    : `<b>Breaking point:</b> not reached - the system met the criteria even at ${worstStress.users} users. Increase STRESS_STAGES in tests/config.js to push harder.`);
  if (firstErr) lines.push(`<b>First errors appeared</b> at ${firstErr.users} users (${firstErr.errorPct}% of requests). Errors were mostly HTTP 503 (server overloaded / request queue full) and client timeouts.`);
  lines.push(`<b>Response-time behaviour:</b> average response time moved from ${load[0].avgMs} ms (${load[0].users} users) to ${worstStress.avgMs} ms (${worstStress.users} users), i.e. latency grows as the database connection pool saturates and requests wait in the queue.`);
  const ratio = worstStress.rps / (peak ? peak.rps : 1);
  lines.push(`<b>Recovery / degradation:</b> at maximum stress throughput was ${worstStress.rps} req/s (${(ratio * 100).toFixed(0)}% of peak). ${ratio < 0.8 ? 'Throughput dropped under extreme load, which shows the system degrades when overloaded.' : 'Throughput stayed close to peak because excess requests were rejected quickly (graceful degradation).'}`);

  const rec = [
    'Increase database connection-pool size or add read replicas / caching (e.g. Redis) for product listing and search.',
    'Add horizontal scaling (more app instances behind a load balancer) with auto-scaling triggered before the breaking point.',
    'Keep the overload protection (queue limit -> HTTP 503) and add rate limiting plus retry-with-backoff on the client.',
    'Optimise the slowest endpoints from the baseline table first (checkout and search use the most database time).',
    'Re-run these tests after every optimisation and compare reports to confirm the improvement.',
  ];
  return { lines, rec, loadOk, breaking, maxStable, peak, config };
}

function buildReport(r) {
  const a = analyse(r);
  const sla = r.config.SLA;
  const cpu = os.cpus();
  const labels = (arr) => JSON.stringify(arr.map((x) => x.users));
  const col = (arr, k) => JSON.stringify(arr.map((x) => x[k]));
  const chart = (id, title, data, ylab) => `<div class="chart"><h4>${title}</h4><canvas id="${id}"></canvas></div>
  <script>new Chart(document.getElementById('${id}'),{type:'line',data:{labels:${labels(data.arr)},datasets:${data.sets}},
  options:{plugins:{legend:{display:${data.legend}}},scales:{x:{title:{display:true,text:'Concurrent users'}},y:{title:{display:true,text:'${ylab}'},beginAtZero:true}}}});</script>`;
  const set = (arr, k, c, name) => `{label:'${name}',data:${col(arr, k)},borderColor:'${c}',backgroundColor:'${c}',tension:.2}`;
  const both = [...r.load, ...r.stress];

  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Performance Test Report</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
 body{font-family:Segoe UI,Arial,sans-serif;max-width:1050px;margin:0 auto;padding:24px;color:#222;line-height:1.5}
 h1{color:#1f3a5f;border-bottom:3px solid #1f3a5f;padding-bottom:8px} h2{color:#1f3a5f;margin-top:32px}
 table{border-collapse:collapse;width:100%;font-size:13px;margin:10px 0} th,td{border:1px solid #ccc;padding:6px 8px;text-align:center}
 th{background:#1f3a5f;color:#fff} td:first-child{text-align:left} .ok{color:#1a7f37;font-weight:700} .bad{color:#c62828;font-weight:700}
 .grid{display:grid;grid-template-columns:1fr 1fr;gap:20px} .chart{border:1px solid #ddd;border-radius:8px;padding:10px}
 .kpi{display:flex;gap:12px;flex-wrap:wrap}.kpi div{flex:1;min-width:150px;background:#eef3f9;border-radius:8px;padding:12px;text-align:center}
 .kpi b{display:block;font-size:22px;color:#1f3a5f} li{margin:6px 0} @media print{.chart{break-inside:avoid}}
</style></head><body>
<h1>Performance Test Report - E-commerce Application</h1>
<p><b>Test type:</b> Load Testing and Stress Testing &nbsp;|&nbsp; <b>Tool:</b> autocannon (Node.js) &nbsp;|&nbsp; <b>Date:</b> ${new Date(r.startedAt).toLocaleString()}</p>

<h2>1. Objective</h2>
<p>To evaluate the performance of the e-commerce application (ShopEasy) under expected (load) and extreme (stress) user traffic by measuring <b>response time</b>, <b>throughput</b> and <b>error rate</b>, and to identify its capacity limit (breaking point).</p>

<h2>2. Test Environment</h2>
<table><tr><td>Application</td><td>Node.js + Express e-commerce demo (in-memory data, simulated DB pool)</td></tr>
<tr><td>Target URL</td><td>${esc(r.config.BASE_URL)}</td></tr>
<tr><td>Machine</td><td>${esc(cpu[0] ? cpu[0].model : 'n/a')} x ${cpu.length} cores, ${(os.totalmem() / 1e9).toFixed(1)} GB RAM, ${os.platform()} ${os.release()}</td></tr>
<tr><td>Node.js</td><td>${process.version}</td></tr>
<tr><td>Stage duration</td><td>${r.config.DURATION} s per stage</td></tr></table>

<h2>3. Test Scenarios</h2>
<table><tr><th>Phase</th><th>Description</th><th>Virtual users</th></tr>
<tr><td>Baseline</td><td>Each endpoint tested alone (browse, detail, search, add-to-cart, checkout)</td><td>10</td></tr>
<tr><td>Load test</td><td>Realistic mix: 3 browse : 2 detail : 2 search : 2 add-to-cart : 1 checkout, users increased to expected peak</td><td>${r.config.LOAD_STAGES.join(', ')}</td></tr>
<tr><td>Stress test</td><td>Same mix, users pushed beyond capacity to find the breaking point</td><td>${r.config.STRESS_STAGES.join(', ')}</td></tr></table>
<p><b>Acceptance criteria (SLA):</b> average response time &le; ${sla.avgMs} ms, p99 &le; ${sla.p99Ms} ms, error rate &le; ${sla.errorPct}%.</p>

<h2>4. Summary</h2>
<div class="kpi">
 <div><b>${a.peak ? a.peak.rps : '-'}</b>Peak throughput (req/s)</div>
 <div><b>${a.maxStable ? a.maxStable.rps : '-'}</b>Max stable throughput (req/s)</div>
 <div><b>${a.breaking ? a.breaking.users : 'Not reached'}</b>Breaking point (users)</div>
 <div><b class="${a.loadOk ? 'ok' : 'bad'}">${a.loadOk ? 'PASS' : 'FAIL'}</b>Load test result</div>
</div>

<h2>5. Results</h2>
<h3>5.1 Baseline - per endpoint (10 users)</h3>${table(r.baseline)}
<h3>5.2 Load test</h3>${table(r.load)}
<h3>5.3 Stress test</h3>${table(r.stress)}

<h2>6. Graphs</h2><div class="grid">
${chart('c1', 'Response time vs users', { arr: both, legend: 'true', sets: '[' + [set(both, 'avgMs', '#1f77b4', 'Average'), set(both, 'p90Ms', '#ff7f0e', 'p90'), set(both, 'p99Ms', '#d62728', 'p99')].join(',') + ']' }, 'ms')}
${chart('c2', 'Throughput vs users', { arr: both, legend: 'false', sets: '[' + set(both, 'rps', '#2ca02c', 'Req/s') + ']' }, 'Successful requests / second')}
${chart('c3', 'Error rate vs users', { arr: both, legend: 'false', sets: '[' + set(both, 'errorPct', '#d62728', 'Error %') + ']' }, 'Error %')}
${chart('c4', 'Data throughput vs users', { arr: both, legend: 'false', sets: '[' + set(both, 'mbPerSec', '#9467bd', 'MB/s') + ']' }, 'MB / second')}
</div>
<p style="font-size:12px;color:#666">Graphs need internet access once to load Chart.js; the tables above work offline.</p>

<h2>7. Analysis</h2><ul>${a.lines.map((l) => `<li>${l}</li>`).join('')}</ul>

<h2>8. Metric definitions</h2>
<ul><li><b>Response time</b> - time from sending a request to receiving the response (avg, p50, p90, p99).</li>
<li><b>Throughput</b> - successful requests handled per second (req/s) and data transferred per second (MB/s).</li>
<li><b>Error rate</b> - (failed requests + timeouts + connection errors) / total requests x 100.</li>
<li><b>Load testing</b> - behaviour under expected/peak users. <b>Stress testing</b> - behaviour beyond capacity to find the breaking point and how the system fails/recovers.</li></ul>

<h2>9. Recommendations</h2><ol>${a.rec.map((x) => `<li>${x}</li>`).join('')}</ol>

<h2>10. Conclusion</h2>
<p>${a.loadOk ? 'The application performs within the defined criteria under expected load.' : 'The application does not meet the criteria under expected load and needs optimisation.'}
${a.breaking ? `Its capacity limit was found at about ${a.breaking.users} concurrent users, after which response time and error rate rise sharply.` : 'No breaking point was found within the tested range.'}
Applying the recommendations above should increase capacity and improve resilience.</p>

<h2>11. Limitations</h2>
<p>Test client and application ran on the same machine, so they compete for CPU; results are indicative and not identical to production. Results vary slightly from run to run.</p>
</body></html>`;
}

module.exports = { buildReport };
