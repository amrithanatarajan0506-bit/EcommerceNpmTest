/**
 * Demo E-commerce application (system under test).
 * In-memory data + a simulated database with a limited connection pool,
 * so the app shows realistic behaviour under load:
 *   - latency grows when the pool is busy (requests wait in a queue)
 *   - when the queue is full the app answers HTTP 503 (overload)
 */
const express = require('express');
const path = require('path');

const PORT = process.env.PORT || 3000;
const DB_POOL = Number(process.env.DB_POOL || 20);     // max parallel "DB queries"
const MAX_QUEUE = Number(process.env.MAX_QUEUE || 300); // max waiting queries

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Fake data ----------
const categories = ['phone', 'laptop', 'camera', 'watch', 'headphone'];
const products = Array.from({ length: 60 }, (_, i) => ({
  id: i + 1,
  name: `${categories[i % 5]} model ${i + 1}`,
  category: categories[i % 5],
  price: 500 + ((i * 137) % 9500),
  stock: 100,
}));
const carts = new Map();
let orderCount = 0;

// ---------- Simulated DB with limited pool ----------
let active = 0;
const queue = [];
function db(ms) {
  return new Promise((resolve, reject) => {
    const run = () => {
      active++;
      setTimeout(() => {
        active--;
        const next = queue.shift();
        if (next) next();
        resolve();
      }, ms);
    };
    if (active < DB_POOL) run();
    else if (queue.length < MAX_QUEUE) queue.push(run);
    else reject(new Error('DB_OVERLOADED'));
  });
}
const wrap = (fn) => (req, res) =>
  fn(req, res).catch(() => res.status(503).json({ error: 'Service busy, try again' }));

// ---------- API ----------
app.get('/api/health', (req, res) => res.json({ status: 'ok', active, queued: queue.length }));

app.get('/api/products', wrap(async (req, res) => {
  await db(15);
  const page = Number(req.query.page || 1);
  res.json(products.slice((page - 1) * 12, page * 12));
}));

app.get('/api/products/:id', wrap(async (req, res) => {
  await db(10);
  const p = products.find((x) => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
}));

app.get('/api/search', wrap(async (req, res) => {
  await db(25);
  const q = String(req.query.q || '').toLowerCase();
  res.json(products.filter((p) => p.name.includes(q)).slice(0, 12));
}));

app.post('/api/cart', wrap(async (req, res) => {
  await db(10);
  const { userId = 'guest', productId = 1, qty = 1 } = req.body || {};
  const cart = carts.get(userId) || [];
  cart.push({ productId, qty });
  if (cart.length > 20) cart.shift();
  carts.set(userId, cart);
  res.status(201).json({ items: cart.length });
}));

app.post('/api/checkout', wrap(async (req, res) => {
  await db(25); // validate stock
  await db(25); // create order + payment
  orderCount++;
  res.status(201).json({ orderId: orderCount, status: 'PLACED' });
}));

if (require.main === module) {
  app.listen(PORT, () => console.log(`E-commerce app running on http://localhost:${PORT}`));
}
module.exports = app;
